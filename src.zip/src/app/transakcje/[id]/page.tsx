import { notFound, redirect } from "next/navigation";
import { db } from "@/db";
import { campaigns, listings, meetingProposals, meetingReadiness, meetings, ratings, transactionEvents, transactions, users } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { TransactionControls } from "@/components/transaction-controls";
import { Badge } from "@/components/ui";
import { ReportForm } from "@/components/action-widgets";
import { AdminPaymentVerification } from "@/components/admin-controls";
import { CalendarIcon, HandHeartIcon, MapPinIcon, ShieldIcon, UserIcon } from "@/components/icons";
import { formatMoney } from "@/lib/auction-logic";
import { paymentsEnabled } from "@/lib/environment";

export const dynamic = "force-dynamic";

export default async function TransactionPage({ params }: { params: Promise<{ id: string }> }) {
  const allowPayments = paymentsEnabled();
  const user = await getCurrentUser(); if (!user) redirect("/logowanie");
  const { id } = await params;
  const [transaction] = await db.select().from(transactions).where(eq(transactions.id,id)).limit(1);
  if (!transaction) notFound();
  const role = user.id===transaction.winnerId?"buyer":user.id===transaction.sellerId?"seller":null;
  if (!role&&user.role!=="admin") notFound();
  const [[listing],[buyer],[seller],[campaign],proposals,[meeting],[rating],events,readinessRows] = await Promise.all([
    db.select().from(listings).where(eq(listings.id,transaction.listingId)).limit(1),
    db.select().from(users).where(eq(users.id,transaction.winnerId)).limit(1),
    db.select().from(users).where(eq(users.id,transaction.sellerId)).limit(1),
    transaction.campaignId
      ? db.select().from(campaigns).where(eq(campaigns.id, transaction.campaignId)).limit(1)
      : db.select().from(campaigns).where(eq(campaigns.isActive, true)).limit(1),
    db.select({id:meetingProposals.id,date:meetingProposals.date,timeRange:meetingProposals.timeRange,location:meetingProposals.location,message:meetingProposals.message,proposedBy:meetingProposals.proposedBy,proposerNickname:users.nickname}).from(meetingProposals).innerJoin(users,eq(users.id,meetingProposals.proposedBy)).where(eq(meetingProposals.transactionId,id)).orderBy(meetingProposals.createdAt),
    db.select().from(meetings).where(eq(meetings.transactionId,id)).limit(1),
    db.select().from(ratings).where(and(eq(ratings.transactionId,id),eq(ratings.raterId,user.id))).limit(1),
    db.select().from(transactionEvents).where(eq(transactionEvents.transactionId,id)).orderBy(transactionEvents.createdAt),
    db.select().from(meetingReadiness).where(eq(meetingReadiness.transactionId,id)),
  ]);
  const currentReadiness = readinessRows.find((row)=>row.userId === user.id);
  const otherReadiness = readinessRows.find((row)=>row.userId !== user.id);

  return <main className="page-shell max-w-5xl py-10">
    <div className="border-b border-slate-200 pb-7">
      <div className="flex flex-wrap items-start justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-[.14em] text-brand-600">Centrum przekazania</p><h1 className="text-balance mt-2 text-3xl font-bold tracking-[-.03em] text-ink">{listing?.title??"Transakcja"}</h1><p className="mt-3 text-sm text-slate-600">Wylicytowana kwota: <strong className="text-brand-800">{formatMoney(transaction.amount)}</strong>{Number(transaction.plannedDonationAmount ?? transaction.amount) > Number(transaction.amount) && <> · Planowana wpłata: <strong className="text-emerald-700">{formatMoney(transaction.plannedDonationAmount!)}</strong></>}</p></div><Badge tone="brand">{human(transaction.status)}</Badge></div>
      <div className="mt-6 grid gap-4 sm:grid-cols-3"><Meta icon={UserIcon} label="Kupujący" value={buyer?.nickname??"-"}/><Meta icon={UserIcon} label="Wystawiający" value={seller?.nickname??"-"}/><Meta icon={HandHeartIcon} label="Zbiórka" value={campaign?.name??"Brak"}/></div>
    </div>

    {meeting&&<div className="mt-6 rounded-xl border border-brand-200 bg-brand-50/60 p-5"><div className="flex gap-4"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white text-brand-700 shadow-sm"><CalendarIcon size={20}/></span><div><p className="font-bold text-ink">Ustalone spotkanie</p><p className="mt-1 text-sm text-slate-600">{new Date(`${meeting.date}T12:00:00`).toLocaleDateString("pl-PL",{weekday:"long",day:"numeric",month:"long"})}, {meeting.timeRange}</p><p className="mt-1 inline-flex items-center gap-1.5 text-sm text-slate-600"><MapPinIcon size={15}/>{meeting.location}</p></div></div></div>}

    {!allowPayments && <div className="mt-6"><Badge tone="warning">TRYB TESTOWY - płatności wyłączone</Badge></div>}
    <div className="mt-7">{role ? <TransactionControls data={{
      id,
      status: transaction.status,
      role,
      amount: transaction.amount,
      plannedDonationAmount: transaction.plannedDonationAmount ?? transaction.amount,
      donationCode: transaction.donationCode,
      campaignUrl: allowPayments ? (transaction.campaignUrlSnapshot ?? campaign?.externalUrl ?? "#") : "#",
      piggyBankUrl: allowPayments ? (transaction.piggyBankUrlSnapshot ?? campaign?.piggyBankUrl ?? null) : null,
      terminalUrl: allowPayments ? (transaction.terminalUrlSnapshot ?? campaign?.terminalUrl ?? null) : null,
      campaignName: transaction.campaignNameSnapshot ?? campaign?.name ?? "Zbiórka Siepomaga",
      campaignProvider: transaction.campaignProviderSnapshot ?? campaign?.provider ?? "SIEPOMAGA",
      paymentLimit: campaign?.paymentLimit ?? "500",
      proposals,
      currentUserId: user.id,
      buyerPresence: Boolean(transaction.buyerConfirmedPresenceAt),
      sellerPresence: Boolean(transaction.sellerConfirmedPresenceAt),
      buyerDonationConfirmed: Boolean(transaction.buyerDonationConfirmedAt),
      sellerDonationConfirmed: Boolean(transaction.sellerDonationConfirmedAt),
      buyerHandover: Boolean(transaction.buyerConfirmedHandoverAt),
      sellerHandover: Boolean(transaction.sellerConfirmedHandoverAt),
      alreadyRated: Boolean(rating),
      readinessConfirmed: Boolean(currentReadiness?.confirmedAt),
      otherPartyReady: Boolean(otherReadiness?.confirmedAt),
    }}/> : <div className="space-y-5"><div className="rounded-xl border border-slate-200 bg-white p-5"><p className="font-semibold text-ink">Podgląd administratora</p><p className="mt-2 text-sm leading-6 text-slate-600">Administrator nie potwierdza obecności ani przekazania za strony. Może zweryfikować zaksięgowany przelew tradycyjny.</p></div>{transaction.status === "OCZEKUJE_NA_WERYFIKACJE" && <AdminPaymentVerification transactionId={id}/>}</div>}</div>

    <section className="mt-8 rounded-xl border border-slate-200 bg-white p-5"><h2 className="text-lg font-bold text-ink">Dziennik zdarzeń</h2><p className="mt-1 text-sm text-slate-500">Historia ważnych kroków pomaga wyjaśniać problemy i spory.</p><ol className="mt-5 space-y-4 border-l border-slate-200 pl-5">{events.length?events.map((event)=><li key={event.id} className="relative"><span className="absolute -left-[25px] top-1.5 h-2 w-2 rounded-full bg-brand-700"/><p className="text-sm font-semibold text-ink">{event.title}</p>{event.details&&<p className="mt-1 text-sm text-slate-600">{event.details}</p>}<time className="mt-1 block text-xs text-slate-400">{event.createdAt.toLocaleString("pl-PL",{dateStyle:"medium",timeStyle:"short"})}</time></li>):<li className="text-sm text-slate-500">Zdarzenia pojawią się po wykonaniu kolejnych kroków.</li>}</ol></section>

    <div className="mt-7 grid gap-5 sm:grid-cols-[1fr_auto] sm:items-center rounded-xl border border-amber-300 bg-amber-50 p-5"><div className="flex gap-3"><ShieldIcon size={21} className="mt-0.5 shrink-0 text-amber-800"/><div><h2 className="font-bold text-amber-950">Zatrzymaj proces, gdy coś się nie zgadza</h2><p className="mt-1 text-sm leading-6 text-amber-900">Nie wykonuj kolejnego kroku. Zachowaj wiadomości i zgłoś problem administratorowi.</p></div></div><ReportForm targetType="TRANSACTION" targetId={id}/></div>
  </main>;
}

function Meta({icon:Icon,label,value}:{icon:typeof ShieldIcon;label:string;value:string}){return <div className="flex gap-3"><span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-slate-50 text-brand-700"><Icon size={18}/></span><div><p className="text-xs text-slate-500">{label}</p><p className="line-clamp-2 text-sm font-semibold text-ink">{value}</p></div></div>;}
function human(value:string){return value.toLowerCase().replaceAll("_"," ").replace(/^./,(m)=>m.toUpperCase());}
