import Link from "next/link";

import { Bullets, ContentPage, H2, LegalNote, Numbered, P } from "@/components/content-page";

export default function BiddingRulesPage() {
  return (
    <ContentPage
      eyebrow="Integralna część regulaminu"
      title="Zasady licytacji"
      intro="Zasady określają sposób składania ofert, ustalania wyniku aukcji i bezpiecznego wykonania zobowiązania po wygranej."
      legal
    >
      <H2>1. Znaczenie oferty</H2>
      <P>
        Oferta zostaje zapisana dopiero po podaniu kwoty i jej jednoznacznym potwierdzeniu na ekranie informującym o wiążącym charakterze licytacji.
        Samo wpisanie kwoty, przejście do logowania albo otwarcie okna potwierdzenia nie składa oferty.
      </P>
      <LegalNote>
        Wylicytowana kwota nie jest przekazywana wystawiającemu ani LicytujDobro. Zwycięzca zobowiązuje się wykonać wpłatę tej kwoty
        bezpośrednio na oficjalną zbiórkę wskazaną w serwisie, a wystawiający – po spełnieniu warunków – przekazać opisany przedmiot.
      </LegalNote>

      <H2>2. Warunki udziału</H2>
      <Bullets>
        <li>licytować może zalogowana, pełnoletnia osoba prywatna z wymaganym potwierdzeniem kontaktu;</li>
        <li>nie wolno licytować własnego przedmiotu ani uzgadniać ofert w celu sztucznego podnoszenia kwoty;</li>
        <li>użytkownik składa ofertę tylko wtedy, gdy realnie może wykonać wpłatę i odebrać przedmiot;</li>
        <li>ograniczenie konta, blokada licytowania albo naruszenie regulaminu może uniemożliwić zapisanie oferty.</li>
      </Bullets>

      <H2>3. Cena początkowa i minimalne przebicie</H2>
      <P>
        Pierwsza oferta może być równa cenie początkowej. Każda następna musi być co najmniej równa minimalnej kolejnej kwocie pokazanej przez system.
        Serwer odrzuci ofertę, która w chwili zapisu jest za niska, nawet jeżeli użytkownik wcześniej widział inną wartość.
      </P>

      <H2>4. Kolejność i czas ofert</H2>
      <Numbered>
        <li>O przyjęciu oferty decyduje czas jej prawidłowego zapisania przez serwer, a nie czas kliknięcia w przeglądarce.</li>
        <li>Najwyższa prawidłowo zapisana oferta prowadzi w aukcji.</li>
        <li>W razie identycznej kwoty pierwszeństwo ma oferta wcześniej zapisana przez serwer.</li>
        <li>Oferta złożona w ostatnich dwóch minutach przedłuża zakończenie o dwie minuty, łącznie maksymalnie o dwadzieścia minut.</li>
        <li>Po osiągnięciu maksymalnego przedłużenia aukcja kończy się o czasie wskazanym przez system.</li>
      </Numbered>

      <H2>5. Pomyłka i wycofanie oferty</H2>
      <P>
        Użytkownik nie może samodzielnie usuwać prawidłowo potwierdzonej oferty. Oczywistą pomyłkę, przejęcie konta lub błąd techniczny należy zgłosić niezwłocznie,
        najlepiej przed zakończeniem aukcji. Operator może anulować ofertę po sprawdzeniu logów i okoliczności, ale nie ma obowiązku uznać każdego wniosku.
      </P>
      <P>
        Nadużywanie procedury, składanie ofert bez zamiaru ich wykonania lub powtarzające się rezygnacje mogą skutkować ostrzeżeniem, czasowym ograniczeniem albo blokadą konta.
      </P>

      <H2>6. Zakończenie i wyłonienie zwycięzcy</H2>
      <P>
        Po zakończeniu aukcji zwycięzcą zostaje użytkownik z najwyższą ważną ofertą. System tworzy centrum przekazania i wyznacza terminy wykonania kolejnych czynności.
        Jeżeli zwycięzca nie potwierdzi udziału lub nie współdziała, operator może anulować wynik, zastosować środek wobec konta albo – gdy funkcja jest dostępna – zaproponować przedmiot kolejnej osobie lub ponownie uruchomić aukcję.
      </P>

      <H2>7. Oględziny przed wpłatą</H2>
      <Bullets>
        <li>strony ustalają termin i bezpieczne miejsce spotkania;</li>
        <li>zwycięzca porównuje przedmiot ze zdjęciami, opisem, stanem, kompletnością i wskazanymi wadami;</li>
        <li>wpłata jest wykonywana dopiero po zaakceptowaniu przedmiotu;</li>
        <li>istotna niezgodność uprawnia do zatrzymania procesu i zgłoszenia sprawy bez wykonywania wpłaty;</li>
        <li>zwykłe ślady używania ujawnione w opisie nie stanowią niezgodności.</li>
      </Bullets>

      <H2>8. Wykonanie wpłaty</H2>
      <P>
        Zwycięzca otwiera wyłącznie oficjalny link do zbiórki pokazany przez LicytujDobro, sprawdza domenę i odbiorcę, a następnie wpłaca co najmniej wylicytowaną kwotę.
        Może dobrowolnie wpłacić więcej, lecz dodatkowa kwota nie jest warunkiem przekazania przedmiotu.
      </P>
      <P>
        Kod BLIK wpisuje się wyłącznie w zewnętrznym, oficjalnym procesie płatniczym. Nie wolno wysyłać kodu BLIK, danych karty, hasła ani danych bankowych wystawiającemu,
        operatorowi lub w wiadomości. Sam zrzut ekranu nie musi stanowić wystarczającego potwierdzenia wpłaty.
      </P>

      <H2>9. Przekazanie przedmiotu</H2>
      <P>
        Wystawiający przekazuje przedmiot po wiarygodnym potwierdzeniu wpłaty zgodnie z procesem serwisu. Strony potwierdzają wykonanie swoich czynności w centrum przekazania.
        Potwierdzenie w LicytujDobro dokumentuje przebieg procesu, ale nie zastępuje dokumentu bankowego ani danych zewnętrznego operatora zbiórki.
      </P>

      <H2>10. Awaria lub przerwanie procesu</H2>
      <P>
        Przy braku Internetu, awarii banku, zewnętrznej zbiórki albo serwisu strony zatrzymują proces. Przedmiot pozostaje u wystawiającego,
        a wpłata nie powinna być wykonywana alternatywną drogą wskazaną w prywatnej wiadomości. Po przywróceniu działania strony kontynuują proces albo zgłaszają problem.
      </P>

      <H2>11. Aukcje specjalne i kolejność prezentacji</H2>
      <P>
        Oznaczenie „aukcja specjalna” może zostać nadane ręcznie wyjątkowemu przedmiotowi, np. pamiątce, rękodziełu lub przedmiotowi z autografem.
        Nie jest ono płatnym pozycjonowaniem ani gwarancją jakości. Listy aukcji mogą być układane według czasu zakończenia, liczby ofert, braku ofert,
        kategorii albo filtra wybranego przez użytkownika. Serwis nie sprzedaje wyższych pozycji w wynikach.
      </P>

      <H2>12. Zgłoszenia</H2>
      <P>
        Podejrzenie manipulacji, niezgodności, oszustwa lub problemu z wykonaniem uzgodnienia należy zgłosić przez funkcję przy aukcji lub transakcji albo przez
        <Link href="/prawne/zgloszenia" className="font-semibold text-brand-700 underline"> formularz zgłoszenia treści i naruszeń</Link>.
      </P>
    </ContentPage>
  );
}
