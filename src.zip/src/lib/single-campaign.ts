import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { campaigns } from "@/db/schema";

export async function getConfiguredCampaign() {
  const [campaign] = await db
    .select()
    .from(campaigns)
    .where(and(eq(campaigns.isActive, true), eq(campaigns.isVisible, true)))
    .limit(1);
  return campaign ?? null;
}

export function campaignConfigurationError(campaign: typeof campaigns.$inferSelect | null): string | null {
  if (!campaign) return "Najpierw skonfiguruj jedyną zbiórkę w panelu administratora.";
  if (!campaign.beneficiaryName?.trim()) return "Uzupełnij publiczne imię beneficjenta.";
  if (!campaign.externalUrl?.startsWith("https://")) return "Uzupełnij oficjalny adres zbiórki Siepomaga.";
  if (!campaign.piggyBankUrl?.startsWith("https://")) return "Uzupełnij adres dedykowanej Skarbonki Siepomaga.";
  if (!campaign.terminalUrl?.startsWith("https://") || !new URL(campaign.terminalUrl).pathname.endsWith("/terminal")) {
    return "Uzupełnij adres Terminalu Siepomaga kończący się /terminal.";
  }
  if (Number(campaign.paymentLimit) <= 0 || Number(campaign.paymentLimit) > 500) return "Limit wpłaty musi wynosić od 1 do 500 zł.";
  return null;
}

export function assertCampaignConfigured(campaign: typeof campaigns.$inferSelect | null) {
  const error = campaignConfigurationError(campaign);
  if (error) throw new Error(error);
  return campaign!;
}
